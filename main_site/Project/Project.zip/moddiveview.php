<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional// EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml11-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang = "en"
<head>
    <meta http-equiv="content-type" content="text/html;charset=iso-8859-1" />
    <title>Dive Reservation System</title>
<body bgcolor="RGB(61,100,165)" >
<font face="Arial" size="2" color="white">
<div id="header">
<center><img src="Images\banner.jpg"></center>
</div>
<div id="navigation">
<table border="0" width="974" cellspacing="0" align="center">
<tr>
<td width="200" valign="top" align="left" bgcolor="RGB(61,100,165)">
<br><a href ="index.php"><img src="Images\Home.jpg" border="0"></a><br>
<a href ="DiveReg.php"><img src="Images\divereg.jpg" border="0"></a><br>
<a href ="modify_view_dive.php"><img src="Images\divemod.jpg" border="0"></a><br>
<a href ="canceldiveevent.php"><img src="Images\divecan.jpg" border="0"></a><br>
<a href ="custreg.php"><img src="Images\custreg.jpg" border="0"></a><br>
<a href ="modify_view_cust.php"><img src="Images\custmod.jpg" border="0"></a><br>
<a href ="cancelcustomerregistration.php"><img src="Images\custcan.jpg" border="0"></a><br>
<a href="view_dive_schedule.php"><img src="Images\diveview.jpg" border="0"></a><br>
<a href="view_customer_list.php"><img src="Images\custview.jpg" border="0"></a><br>

<p><!--<img src="Images\tellno.jpg">-->
</div>
</td>
<td width="774" bgcolor="RGB(61,100,165)" valign="top">
<div align="left">
<!-- all contents go here -->
<?php
$divenum = $_POST['hideval'];
//$user = "root";
//$pass = "dive";
//$db = "sheaqu_dive";
//$link = @mysql_connect( "localhost", $user, $pass );

$user = "sheaqu_dive";
$pass = "dive";
$db = "sheaqu_dive";
$link = @mysql_connect( "mysql4.freehostia.com", $user, $pass );

if (!$link) {
die("Couldn't connect to MySQL: ".mysql_error());
}
mysql_select_db($db,$link)
or die ( "Couldn't open $db: ".mysql_error() );
$query = mysql_query("select * from dive_info",$link );
If ($query == TRUE) {
} else { print "Update cannot be performed"; }
$result = @mysql_query("SELECT * FROM dive_info WHERE dive_number=".$divenum."",$link);
$num_rows = mysql_num_rows( $result );
$row = mysql_fetch_assoc($result);
echo '<form method="post" action="divemod.php"><p>';
echo '<fieldset><legend><font color="white">Dive Event Information </font></legend>';
echo '<input type="hidden" name="dive_number" value='.$divenum.'>';
echo '<table border="0" width="80%" align="center">';
echo '<tr><td width="35%"><b>&nbsp&nbsp&nbsp&nbsp Dive Name:</td></b>';
echo '<td>'.$row['dive_name'].'</td></p>';
echo '<tr><td><b>&nbsp&nbsp&nbsp&nbsp Boat Name:</td></b>';
echo '<td>'.$row['boat_name'].'</td></p>';
echo '<tr><td><b>&nbsp&nbsp&nbsp&nbsp Limit:</td></b>';
echo '<td>'.$row['limits'].'</td></p>';
echo '<tr><td><b>&nbsp&nbsp&nbsp&nbsp Price:</td></b>';
echo '<td>'.$row['price'].'</td></p>';
echo '<tr><td><b>&nbsp&nbsp&nbsp&nbsp Marina:</td></b>';
echo '<td>'.$row['marina'].'</td></p>';
echo '<tr><td><b>&nbsp&nbsp&nbsp&nbsp Marina Address:</td></b>';
echo '<td>'.$row['marina_add'].'</td></p>';
echo '<tr><td><b>&nbsp&nbsp&nbsp&nbsp Alternate Marina:</td></b>';
echo '<td>'.$row['alt_marina'].'</td></p>';
echo '<tr><td><b>&nbsp&nbsp&nbsp&nbsp Alternate Marina Address:</td></b>';
echo '<td>'.$row['alt_marina_add'].'</td></p>';
echo '<tr><td><b>&nbsp&nbsp&nbsp&nbsp Show Time:</td></b>';
echo '<td>'.$row['showtime'].'</td></p>';
echo '<tr><td><b>&nbsp&nbsp&nbsp&nbsp Remarks:</td></b>';
echo '<td>'.$row['remarks'].'</td></p><br>';
echo '</table><p>';
echo '<div align="center"><input type="submit" name="submit" value="Modify Dive Event Information" /></div><p></fieldset></form>';
?>
<!--end of center side-->
</div>
</td>
<!-- right side of webpage-->
</tr>
</table>
<br>
<?php include "footer.php" ?>
</font>
</body>
</html>