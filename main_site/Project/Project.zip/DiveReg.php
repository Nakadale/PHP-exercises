<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional// EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml11-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang = "en"
<head>
    <meta http-equiv="content-type" content="text/html;charset=iso-8859-1" />
    <title>Dive Reservation System</title>
<body bgcolor="RGB(61,100,165)">
<font face="Arial" size="2" color="white">
<div id="header">
<center><img src="Images\banner.jpg"></center>
</div>
<div id="navigation">
<table border="0" width="974" cellspacing="0" align="center">
<tr>
<td width="200" valign="top" align="left" bgcolor="RGB(61,100,165)">
<br><a href ="index.php"><img src="Images\Home.jpg" border="0"></a><br>
<a href ="DiveReg.php"><img src="Images\divereg.jpg" border="0"></a><br>
<a href ="modify_view_dive.php"><img src="Images\divemod.jpg" border="0"></a><br>
<a href ="canceldiveevent.php"><img src="Images\divecan.jpg" border="0"></a><br>
<a href ="custreg.php"><img src="Images\custreg.jpg" border="0"></a><br>
<a href ="modify_view_cust.php"><img src="Images\custmod.jpg" border="0"></a><br>
<a href ="cancelcustomerregistration.php"><img src="Images\custcan.jpg" border="0"></a><br>
<a href="view_dive_schedule.php"><img src="Images\diveview.jpg" border="0"></a><br>
<a href="view_customer_list.php"><img src="Images\custview.jpg" border="0"></a><br>

<p><!--<img src="Images\tellno.jpg">-->
</div>
</td>
<td width="774" bgcolor="RGB(61,100,165)" valign="top">
<div align="left">
<!-- all contents go here -->
<form action="registration_done.php" method="post"><p>
<fieldset><legend><font color="white">Dive Event Information</font></legend>
<p>
<table border="0" width="80%" align="center">
<tr><td><b>&nbsp&nbsp&nbsp&nbsp Dive Date:</b></td>
<td>
<?php
//Make the months array:
$months = array(1 => 'January', 'Febuary', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December');
//Make the days and years arrays:
$days = range(1,31);
$years = range(2008, 2018);
//Make the months pull-down menu:
echo '<select name="month">';
foreach ($months as $months => $value){	echo "<option value=\"$months\">$value</option>\n";}
echo '</select>';
echo '&nbsp&nbsp';
//Make the days pull-down menu:
echo '<select name="day">';
foreach ($days as $days => $value){ echo "<option value=\"$value\">$value</option>\n";}
echo '</select>';
echo '&nbsp&nbsp';
//Make the years pull-down menu:
echo '<select name="year">';
foreach ($years as $years => $value){ echo "<option value=\"$value\">$value</option>\n";}
echo '</select>';
?></td></tr>
<tr><td><b>&nbsp&nbsp&nbsp&nbsp Dive Name:</b></td>
<td><input type="text" name="dive_name" size="40" maxlength="60"/></td></tr></p>
<tr><td><b>&nbsp&nbsp&nbsp&nbsp Boat Name:</b> </td>
<td><input type="text" name="boat_name" size="40" maxlength="60" /></td></tr></p>
<tr><td><b>&nbsp&nbsp&nbsp&nbsp Limit:</b></td>
<td><input type="text" name="limit" size="40" maxlength="60" /></td></tr></p>
<tr><td><b>&nbsp&nbsp&nbsp&nbsp Price:</b></td>
<td><input type="text" name="price" size="40" maxlength="60" /></td></tr></p>
<tr><td><b>&nbsp&nbsp&nbsp&nbsp Marina:</b></td>
<td><input type="text" name="marina" size="40" maxlength="60" /></td></tr></p>
<tr><td><b>&nbsp&nbsp&nbsp&nbsp Marina Address:</td></b>
<td><input type="text" name="marina_add" size="40" maxlength="60" /></td></tr></p>
<tr><td><b>&nbsp&nbsp&nbsp&nbsp Alternate Marina:</td></b>
<td><input type="text" name="alt_marina" size="40" maxlength="60" /></td></tr></p>
<tr><td><b>&nbsp&nbsp&nbsp&nbsp Alternate Marina Address:</td></b>
<td><input type="text" name="alt_marina_add" size="40" maxlength="60" /></td></tr></p>
<tr><td><b>&nbsp&nbsp&nbsp&nbsp Show Time:</td></b>
<td><select name="showtime">
<option value="12:00 AM">12:00 AM</option>
<option value="12:30 AM">12:30 AM</option>
<option value="01:00 AM">01:00 AM</option>
<option value="01:30 AM">01:30 AM</option>
<option value="02:00 AM">02:00 AM</option>
<option value="02:30 AM">02:30 AM</option>
<option value="03:00 AM">03:00 AM</option>
<option value="03:30 AM">03:30 AM</option>
<option value="04:00 AM">04:00 AM</option>
<option value="04:30 AM">04:30 AM</option>
<option value="05:00 AM">05:00 AM</option>
<option value="05:30 AM">05:30 AM</option>
<option value="06:00 AM">06:00 AM</option>
<option value="06:30 AM">06:30 AM</option>
<option value="07:00 AM">07:00 AM</option>
<option value="07:30 AM">07:30 AM</option>
<option value="08:00 AM">08:00 AM</option>
<option value="08:30 AM">08:30 AM</option>
<option value="09:00 AM">09:00 AM</option>
<option value="09:30 AM">09:30 AM</option>
<option value="10:00 AM">10:00 AM</option>
<option value="10:30 AM">10:30 AM</option>
<option value="11:00 AM">11:00 AM</option>
<option value="11:30 AM">11:30 AM</option>
<option value="12:00 PM">12:00 PM</option>
<option value="12:30 PM">12:30 PM</option>
<option value="01:00 PM">01:00 PM</option>
<option value="01:30 PM">01:30 PM</option>
<option value="02:00 PM">02:00 PM</option>
<option value="02:30 PM">02:30 PM</option>
<option value="03:00 PM">03:00 PM</option>
<option value="03:30 PM">03:30 PM</option>
<option value="04:00 PM">04:00 PM</option>
<option value="04:30 PM">04:30 PM</option>
<option value="05:00 PM">05:00 PM</option>
<option value="05:30 PM">05:30 PM</option>
<option value="06:00 PM">06:00 PM</option>
<option value="06:30 PM">06:30 PM</option>
<option value="07:00 PM">07:00 PM</option>
<option value="07:30 PM">07:30 PM</option>
<option value="08:00 PM">08:00 PM</option>
<option value="08:30 PM">08:30 PM</option>
<option value="09:00 PM">09:00 PM</option>
<option value="09:30 PM">09:30 PM</option>
<option value="10:00 PM">10:00 PM</option>
<option value="10:30 PM">10:30 PM</option>
<option value="11:00 PM">11:00 PM</option>
<option value="11:30 PM">11:30 PM</option>
</select></td></p>
<tr><td><b>&nbsp&nbsp&nbsp&nbsp Remarks:</td></b>
<td><textarea name="remarks" rows="3" cols="30" maxlength="255"></textarea></td></p><br>
</table>

<p>
<div align="center"><input type="submit" name="submit" value="Submit" /></div><br>
</fieldset>
</div>
</td>
</tr>
</table>
<br>
<?php include "footer.php" ?>
</font>
</body>
</html>