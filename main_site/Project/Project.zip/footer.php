<div id="footer" align="center">
<br />This Website best viewed on a 1024x768 screen resolution
<br />Copyright &copy; Underdog Development 2009</a>  
<!--| Valid <a
href="http://jigsaw.w3.org/css-validator/">CSS</a> &amp; <a
href="http://validator.w3.org/">XHTML</a></p>-->
</div>