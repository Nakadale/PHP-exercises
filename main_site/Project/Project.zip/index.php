<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional// EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml11-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang = "en"
<head>
    <meta http-equiv="content-type" content="text/html;charset=iso-8859-1" />
    <title>Dive Reservation System</title>
<body bgcolor="RGB(61,100,165)" >
<font face="Arial" size="2" color="white">
<div id="header">
<center><img src="Images\banner.jpg"></center>
</div>
<div id="navigation">
<table border="0" width="974" cellspacing="0" align="center">
<tr>
<td width="200" valign="top" align="left" bgcolor="RGB(61,100,165)">
<br><a href ="index.php"><img src="Images\Home.jpg" border="0"></a><br>
<a href ="DiveReg.php"><img src="Images\divereg.jpg" border="0"></a><br>
<a href ="modify_view_dive.php"><img src="Images\divemod.jpg" border="0"></a><br>
<a href ="canceldiveevent.php"><img src="Images\divecan.jpg" border="0"></a><br>
<a href ="custreg.php"><img src="Images\custreg.jpg" border="0"></a><br>
<a href ="modify_view_cust.php"><img src="Images\custmod.jpg" border="0"></a><br>
<a href ="cancelcustomerregistration.php"><img src="Images\custcan.jpg" border="0"></a><br>
<a href="view_dive_schedule.php"><img src="Images\diveview.jpg" border="0"></a><br>
<a href="view_customer_list.php"><img src="Images\custview.jpg" border="0"></a><br>

<!--<a href=""><img src="Images\logout.jpg" border="0"></a><br>-->
<p><!--<img src="Images\tellno.jpg">-->
</div>
</td>
<td width="774" bgcolor="RGB(61,100,165)" valign="top">
<div align="center">
<!-- all contents go here -->
<?php
//$user = "root";
//$pass = "dive";
//$db = "sheaqu_dive";
//$link = @mysql_connect( "localhost", $user, $pass );
$user = "sheaqu_dive";
$pass = "dive";
$db = "sheaqu_dive";
$link = @mysql_connect( "mysql4.freehostia.com", $user, $pass );
if (!$link) {
die("Couldn't connect to MySQL: ".mysql_error());
}
mysql_select_db($db,$link)
or die ( "Couldn't open $db: ".mysql_error() );
echo '<br><table border="0" valign="top" align="left" cellspacing="0">';
$result = @mysql_query("SELECT * FROM bulletin ORDER BY post_ID DESC",$link);
$num_rows = mysql_num_rows( $result );
while ($row = mysql_fetch_array($result, MYSQL_ASSOC)){ 
echo '<input type="hidden" name="hideval" value="'.$row['post_id'].'"/>';
echo '<tr align="left" bgcolor="RGB(83,137,207)"><td width="774"><font color="white">'.$row['post_date'].',&nbsp&nbsp';
echo '<a href="msg.php?ID='.$row['post_id'].'">'.$row['post_title'].'</font></td></tr>';
echo '</a>';
echo '<tr align="left" bgcolor="RGB(207,228,255)"><td><font color="black">'.$row['post_content'].'<p></font></td></tr>';
}
echo '</table>';
?>
<!-- right side of webpage-->
</div>
</td>
</tr>
</table>
<br>
<?php include "footer.php" ?>
</font>
</body>
</html>