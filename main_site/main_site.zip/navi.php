
	<table style="width:980px;background-color:RGB(89,146,215);">
	<tr><td>
	<a href ="index.php"><img src="Images/Home.jpg" border="0"></a><a href ="projects.php"><img src="Images/Projects.jpg" border="0"></a><a href ="about.php"><img src="Images/About.jpg" border="0"></a><img src="Images/button.jpg" border="0"><img src="Images/button.jpg" border="0"><img src="Images/button.jpg" border="0"><img src="Images/button.jpg" border="0"><img src="Images/button.jpg" border="0"><img src="Images/button.jpg" border="0"><img src="Images/button78.jpg" border="0"></td></tr></table>
	