<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional// EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml11-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang = "en"
<head>
    <meta http-equiv="content-type" content="text/html;charset=iso-8859-1" />
    <title>Dive Reservation System</title>
<body bgcolor="RGB(61,100,165)" >
<font face="Arial" size="2" color="white">
<div id="header">
<center><img src="Images\banner.jpg"></center>
</div>
<div id="navigation" valign="top">
<table border="0" width="974" cellspacing="0" align="center">
<tr>
<td width="200" valign="top" align="left" bgcolor="RGB(61,100,165)">
<br><a href ="index.php"><img src="Images\Home.jpg" border="0"></a><br>
<a href ="DiveReg.php"><img src="Images\divereg.jpg" border="0"></a><br>
<a href ="modify_view_dive.php"><img src="Images\divemod.jpg" border="0"></a><br>
<a href ="canceldiveevent.php"><img src="Images\divecan.jpg" border="0"></a><br>
<a href ="custreg.php"><img src="Images\custreg.jpg" border="0"></a><br>
<a href ="modify_view_cust.php"><img src="Images\custmod.jpg" border="0"></a><br>
<a href ="cancelcustomerregistration.php"><img src="Images\custcan.jpg" border="0"></a><br>
<a href="view_dive_schedule.php"><img src="Images\diveview.jpg" border="0"></a><br>
<a href="view_customer_list.php"><img src="Images\custview.jpg" border="0"></a><br>
<p><!--<img src="Images\tellno.jpg">-->
</div>
</td>
<td width="774" bgcolor="RGB(61,100,165)" valign="top">
<div align="left" valign="top">
<!-- all contents go here -->
<?php
//$user = "root";
//$pass = "dive";
//$db = "sheaqu_dive";
//$link = @mysql_connect( "localhost", $user, $pass );
$user = "sheaqu_dive";
$pass = "dive";
$db = "sheaqu_dive";
$link = @mysql_connect( "mysql4.freehostia.com", $user, $pass );
echo '<font face="Arial" size="2" color="white">';
echo '<br><form method="POST">';
echo 'Sort: <select size="1" height="1" name="sorts">';
echo 	'<option value="1">Asc</option>';
echo 	'<option value="2">Desc</option>';
echo '</select>';
echo '&nbsp&nbsp&nbspKeyword: <input type="text" name="search" size="30" class="text" />';
echo ' <input type="submit" name="submit" value="Search" ></form><br>';
echo '<table cols="2" border="1" cellpadding="0" cellspacing="0" align="center" width="100%">';
echo '<tr bgcolor="RGB(83,137,207)">';
	echo '<td align="center">Cancel Dive Event</td>';
echo '</tr>';
echo '</table>';
echo '<table cols="2" border="1" cellpadding="0" cellspacing="0" align="center" width="100%">';
 echo '<tr bgcolor="RGB(83,137,207)"><form action="divedel.php" method="POST">';
	echo '<td align="center" width="8%">Dive Number</td>';
	echo '<td align="center" width="15%">Dive Date</td>';
	echo '<td align="center" width="13%">Dive Name</td>';
	echo '<td align="center" width="13%">Boat Name</td>';
	echo '<td align="center" width="10%">Marina</td>';
	//echo '<td align="center">Marina Address</td>';
	echo '<td align="center" width="10%">Alternate Marina</td>';
	//echo '<td align="center">Alternate Marina Address</td>';
	echo '<td align="center" width="10%">Show Time</td>';
	echo '<td align="center" width="7%">Limit</td>';
	echo '<td align="center" width="7%">Price</td>';
	echo '<td align="center">Delete</td>';
echo '<p></form></tr>';
$search = $_POST['search'];
$sorts = $_POST['sorts'];
if (!$link) {
die("Couldn't connect to MySQL: ".mysql_error());
}
mysql_select_db($db,$link)
or die ( "Couldn't open $db: ".mysql_error() );
if ($sorts == 1){
$result = @mysql_query("SELECT * FROM dive_info WHERE dive_name LIKE '$search%' OR dive_number LIKE '$search%' OR boat_name LIKE '$search%' ORDER BY dive_number ASC",$link);}
else if ($sorts == 2){
$result = @mysql_query("SELECT * FROM dive_info WHERE dive_name LIKE '$search%' OR dive_number LIKE '$search%' OR boat_name LIKE '$search%' ORDER BY dive_number DESC",$link);}
else if ($sorts == NULL ){
$result = @mysql_query("SELECT * FROM dive_info WHERE dive_name LIKE '$search%' OR dive_number LIKE '$search%' OR boat_name LIKE '$search%' ORDER BY dive_number ASC",$link);}	
$num_rows = mysql_num_rows( $result );
while ($row = mysql_fetch_array($result, MYSQL_ASSOC)){ 
echo '<tr bgcolor="RGB(207,228,255)"><form action="divedel.php" method="POST">';
	echo '<td align="center"><font color="black" />'.$row['dive_number'].'</td>';
	echo '<td align="center"><font color="black" />'.$row['dive_month'].'/'.$row['dive_day'].'/'.$row['dive_year'].'</td>';
	echo '<td align="center"><font color="black" />'.$row['dive_name'].'</td>';
	echo '<td align="center"><font color="black" />'.$row['boat_name'].'</td>';
	echo '<td align="center"><font color="black" />'.$row['marina'].'</td>';
	//echo '<td align="center">'.$row['marina_add'].'</td>';
	echo '<td align="center"><font color="black" />'.$row['alt_marina'].'</td>';
	//echo '<td align="center">'.$row['alt_marina_add'].'</td>';
	echo '<td align="center"><font color="black" />'.$row['showtime'].'</td>';
	echo '<td align="center"><font color="black" />'.$row['limits'].'</td>';
	echo '<td align="center"><font color="black" />'.$row['price'].'</td>';
	echo '<td>';
	echo '<input type="hidden" name="hideval" value="'.$row['dive_number'].'">';
	echo '<input type="submit" name="Edit" value="Delete"></td>';
echo '<p></form></tr>';
}
echo '</table>';
echo '</font>';
?>
<!-- right side of webpage-->
</tr>
</table>
<br>
<?php include "footer.php" ?>
</font>
</body>
</html>