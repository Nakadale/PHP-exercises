<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional// EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml11-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang = "en"
<head>
    <meta http-equiv="content-type" content="text/html;charset=iso-8859-1" />
    <title>Dive Reservation System</title>
<body bgcolor="RGB(61,100,165)" >
<font face="Arial" size="2" color="white">
<div id="header">
<center><img src="Images\banner.jpg"></center>
</div>
<div id="navigation">
<table border="0" width="974" cellspacing="0" align="center">
<tr>
<td width="200" valign="top" align="left" bgcolor="RGB(61,100,165)">
<br><a href ="index.php"><img src="Images\Home.jpg" border="0"></a><br>
<a href ="DiveReg.php"><img src="Images\divereg.jpg" border="0"></a><br>
<a href ="modify_view_dive.php"><img src="Images\divemod.jpg" border="0"></a><br>
<a href ="canceldiveevent.php"><img src="Images\divecan.jpg" border="0"></a><br>
<a href ="custreg.php"><img src="Images\custreg.jpg" border="0"></a><br>
<a href ="modify_view_cust.php"><img src="Images\custmod.jpg" border="0"></a><br>
<a href ="cancelcustomerregistration.php"><img src="Images\custcan.jpg" border="0"></a><br>
<a href="view_dive_schedule.php"><img src="Images\diveview.jpg" border="0"></a><br>
<a href="view_customer_list.php"><img src="Images\custview.jpg" border="0"></a><br>

<p><!--<img src="Images\tellno.jpg">-->
</div>
</td>
<td width="774" bgcolor="RGB(61,100,165)">
<div align="left">
<!-- all contents go here -->
<?php
$dive_name = $_POST['dive_name'];
$company_name = $_POST['company_name'];
$first_name = $_POST['first_name'];
$last_name = $_POST['last_name'];
$home_phone = $_POST['home_phone'];
$work_phone = $_POST['work_phone'];
$mobile_phone = $_POST['mobile_phone'];
$certificate = $_POST['certificate'];
$pax = $_POST['pax'];
$cuft80 = $_POST['80cuft'];
$cuft67 = $_POST['67cuft'];
$rental = $_POST['rental'];
$rental_amt = $_POST['rent_amount'];
$dive_amt = $_POST['dive_amount'];
$total_amt = $_POST['total_amount'];
$remarks = $_POST['remarks'];
$month = $_POST['month'];
$day = $_POST['day'];
$year = $_POST['year'];
//$user = "root";
//$pass = "dive";
//$db = "sheaqu_dive";
//$link = @mysql_connect( "localhost", $user, $pass );
$user = "sheaqu_dive";
$pass = "dive";
$db = "sheaqu_dive";
$link = @mysql_connect( "mysql4.freehostia.com", $user, $pass );
if (!$link) {
die("Couldn't connect to MySQL: ".mysql_error());
}
mysql_select_db($db, $link)
or die ( "Couldn't open $db: ".mysql_error() );
$query = "INSERT INTO cust_info(dive_month, dive_day ,dive_year , dive_name, company_name, first_name, last_name, home_phone, work_phone, mobile_phone, certificate, pax, 80cuft, 67cuft, rental, rent_amount, dive_amount, total_amount, remarks)
values('".$dive_month."','".$dive_day."','".$dive_year."','".$dive_name."', '".$company_name."', '".$first_name."', '".$last_name."', '".$home_phone."', '".$work_phone."', '".$mobile_phone."', '".$certificate."', '".$pax."', '".$cuft80."', '".$cuft67."', '".$rental."', '".$rent_amt."', '".$dive_amt."', '".$total_amt."', '".$remarks."')";
mysql_query($query,$link)
or die ( "INSERT error: ".mysql_error() );
$result = @mysql_query("SELECT * FROM cust_info",$link );
$num_rows = mysql_num_rows( $result );
echo '<br><div align="center">Customer Registration Added!';
echo '<form action="index.php"><input type="submit" value="Back to Main"/></form>';
mysql_close( $link );
?>
<!-- right side of webpage-->
</div>
</tr>
</table>
<br>
<?php include "footer.php" ?>
</font>
</body>
</html>