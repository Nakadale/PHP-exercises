<div id="footer">
<table style="width:980px;"><tr><td><br />
<center>This Website best viewed on a 1024x768 screen resolution
<br />Website developed by Sherwin Lester V. Aquino 2009</center></a>  
<!--| Valid <a
href="http://jigsaw.w3.org/css-validator/">CSS</a> &amp; <a
href="http://validator.w3.org/">XHTML</a></p>-->
<br /><br />
</td></tr></table>
</div>