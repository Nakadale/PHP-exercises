<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional// EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml11-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang = "en"
<head>
    <meta http-equiv="content-type" content="text/html;charset=iso-8859-1" />
    <title>Dive Reservation System</title>
<body bgcolor="RGB(61,100,165)" >
<font face="Arial" size="2" color="white">
<div id="header">
<center><img src="Images\banner.jpg"></center>
</div>
<div id="navigation">
<table border="0" width="974" cellspacing="0" align="center">
<tr>
<td width="200" valign="top" align="left" bgcolor="RGB(61,100,165)">
<br><a href ="index.php"><img src="Images\Home.jpg" border="0"></a><br>
<a href ="DiveReg.php"><img src="Images\divereg.jpg" border="0"></a><br>
<a href ="modify_view_dive.php"><img src="Images\divemod.jpg" border="0"></a><br>
<a href ="canceldiveevent.php"><img src="Images\divecan.jpg" border="0"></a><br>
<a href ="custreg.php"><img src="Images\custreg.jpg" border="0"></a><br>
<a href ="modify_view_cust.php"><img src="Images\custmod.jpg" border="0"></a><br>
<a href ="cancelcustomerregistration.php"><img src="Images\custcan.jpg" border="0"></a><br>
<a href="view_dive_schedule.php"><img src="Images\diveview.jpg" border="0"></a><br>
<a href="view_customer_list.php"><img src="Images\custview.jpg" border="0"></a><br>

<p><!--<img src="Images\tellno.jpg">-->
</div>
</td>
<td width="774" bgcolor="RGB(61,100,165)">
<div align="left">
<!-- all contents go here -->
<?php
$dive_name = $_POST['dive_name'];
$boat_name = $_POST['boat_name'];
$limit = $_POST['limit'];
$price = $_POST['price'];
$marina = $_POST['marina'];
$marina_add = $_POST['marina_add'];
$alt_marina = $_POST['alt_marina'];
$alt_marina_add = $_POST['alt_marina_add'];
$showtime = $_POST['showtime'];
$bbq = $_POST['bbq'];
$remarks = $_POST['remarks'];
$month = $_POST['month'];
$day = $_POST['day'];
$year = $_POST['year'];
$user = "sheaqu_dive";
$pass = "dive";
$db = "sheaqu_dive";
$link = @mysql_connect( "mysql4.freehostia.com", $user, $pass );
//$user = "root";
//$pass = "dive";
//$db = "sheaqu_dive";
//$link = @mysql_connect( "localhost", $user, $pass );
if (!$link) {
die("Couldn't connect to MySQL: ".mysql_error());
}
mysql_select_db($db, $link)
or die ( "Couldn't open $db: ".mysql_error() );
$query = "INSERT INTO dive_info( dive_month, dive_day, dive_year, dive_name, boat_name, limits, price, marina, marina_add, alt_marina, alt_marina_add, showtime, bbq, remarks)
values( '".$month."', '".$day."', '".$year."', '".$dive_name."', '".$boat_name."', '".$limit."', '".$price."', '".$marina."', '".$marina_add."', '".$alt_marina."', '".$alt_marina_add."', '".$showtime."', '".$bbq."', '".$remarks."')";
mysql_query($query,$link)
or die ( "INSERT error: ".mysql_error() );
$result = @mysql_query("SELECT * FROM dive_info",$link );
$num_rows = mysql_num_rows( $result );
echo '<br><div align="center">Dive Event Added!';
echo '<form action="index.php"><input type="submit" value="Back to Main"/></form>';
mysql_close( $link );
?>

</div
</td>
</table>
<br>
<?php include "footer.php" ?>
</font>
</body>
</html>
