<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional// EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml11-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang = "en"
<head>
    <meta http-equiv="content-type" content="text/html;charset=iso-8859-1" />
    <title>Dive Reservation System</title>
<body bgcolor="RGB(61,100,165)" >
<font face="Arial" size="2" color="white">
<div id="header">
<center><img src="Images\banner.jpg"></center>
</div>
<div id="navigation">
<table border="0" width="974" cellspacing="0" align="center">
<tr>
<td width="200" valign="top" align="left" bgcolor="RGB(61,100,165)">
<br><a href ="index.php"><img src="Images\Home.jpg" border="0"></a><br>
<a href ="DiveReg.php"><img src="Images\divereg.jpg" border="0"></a><br>
<a href ="modify_view_dive.php"><img src="Images\divemod.jpg" border="0"></a><br>
<a href ="canceldiveevent.php"><img src="Images\divecan.jpg" border="0"></a><br>
<a href ="custreg.php"><img src="Images\custreg.jpg" border="0"></a><br>
<a href ="modify_view_cust.php"><img src="Images\custmod.jpg" border="0"></a><br>
<a href ="cancelcustomerregistration.php"><img src="Images\custcan.jpg" border="0"></a><br>
<a href="view_dive_schedule.php"><img src="Images\diveview.jpg" border="0"></a><br>
<a href="view_customer_list.php"><img src="Images\custview.jpg" border="0"></a><br>

<p><!--<img src="Images\tellno.jpg">-->
</div>
</td>
<td width="774" bgcolor="RGB(61,100,165)" valign="top">
<div align="left" valign="top">
<!-- all contents go here -->
<form action="Cust_registration_done.php" method="post"><p>
<fieldset><legend><font color="white">Customer Registration</font></legend>
<table border="0" width="80%" align="center">
<tr><td><b>&nbsp&nbsp&nbsp&nbsp Dive Date:</b></td>
<td><?php

// This script make three pull-down menus
// for an html form: months, days, years.

//Make the months array:
$months = array(1 => 'January', 'Febuary', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December');

//Make the days and years arrays:
$days = range(1,31);
$years = range(2008, 2018);

//Make the months pull-down menu:
echo '<select name="month">';
foreach ($months as $months => $value){
	echo "<option value=\"$months\">$value</option>\n";
}
echo '</select>';
echo '&nbsp&nbsp';
//Make the days pull-down menu:
echo '<select name="day">';
foreach ($days as $days => $value){
	echo "<option value=\"$value\">$value</option>\n";
}
echo '</select>';
echo '&nbsp&nbsp';
//Make the years pull-down menu:
echo '<select name="year">';
foreach ($years as $years => $value){
	echo "<option value=\"$value\">$value</option>\n";
}
echo '</select>';

?></td></tr>
<tr><td><b>&nbsp&nbsp&nbsp&nbsp Dive Name:</b></td>
<td><input type="text" name="dive_name" size="20" maxlength="40"/></td></tr></p>
<tr><td><b>&nbsp&nbsp&nbsp&nbsp Company Name:</b></td>
<td><input type="text" name="company_name" size="40" maxlength="255" /></td></tr></p>
<tr><td><b>&nbsp&nbsp&nbsp&nbsp First Name:</b></td>
<td><input type="text" name="first_name" size="40" maxlength="60" /></td></tr></p>
<tr><td><b>&nbsp&nbsp&nbsp&nbsp Last Name:</b></td>
<td><input type="text" name="last_name" size="40" maxlength="60" /></td></tr></p>
<tr><td><b>&nbsp&nbsp&nbsp&nbsp Home Phone:</b></td>
<td><input type="text" name="home_phone" size="40" maxlength="60" /></td></tr></p>
<tr><td><b>&nbsp&nbsp&nbsp&nbsp Work Phone:</b></td>
<td><input type="text" name="work_phone" size="40" maxlength="60" /></td></tr></p>
<tr><td><b>&nbsp&nbsp&nbsp&nbsp Mobile Phone:</b></td>
<td><input type="text" name="mobile_phone" size="40" maxlength="60" /></td></tr></p>
<tr><td><b>&nbsp&nbsp&nbsp&nbsp Certificate:</b></td>
<td><input type="text" name="certificate" size="40" maxlength="60" /></td></tr></p>
<tr><td><b>&nbsp&nbsp&nbsp&nbsp Pax:</b></td>
<td><input type="text" name="pax" size="40" maxlength="60" /></tr></td></p>
<tr><td><b>&nbsp&nbsp&nbsp&nbsp 80cuft:</b></td>
<td><input type="text" name="80cuft" size="40" maxlength="60" /></tr></td></p>
<tr><td><b>&nbsp&nbsp&nbsp&nbsp 67cuft:</b></td>
<td><input type="text" name="67cuft" size="40" maxlength="60" /></tr></td></p>
<tr><td><b>&nbsp&nbsp&nbsp&nbsp Rental:</b></td>
<td><input type="text" name="rental" size="40" maxlength="60" /></tr></td></p>
<tr><td><b>&nbsp&nbsp&nbsp&nbsp Rental Amount:</b></td>
<td><input type="text" name="rent_amount" size="40" maxlength="60" /></tr></td></p>
<tr><td><b>&nbsp&nbsp&nbsp&nbsp Dive Amount:</b></td>
<td><input type="text" name="dive_amount" size="40" maxlength="60" /></tr></td></p>
<tr><td><b>&nbsp&nbsp&nbsp&nbsp Total Amount:</b></td>
<td><input type="text" name="total_amount" size="40" maxlength="60" /></tr></td></p>
<tr><td><b>&nbsp&nbsp&nbsp&nbsp Remarks:</b></td> 
<td><textarea name="remarks" rows="3" cols="30" maxlength="255"></textarea></tr></td></p><br>
</table><p>
<div align="center"><input type="submit" name="submit" value="Submit" /></div>
</fieldset>
<br>
</form>
<!-- right side of webpage-->
</tr>
</table>
<br>
<?php include "footer.php" ?>
</font>
</body>
</html>
