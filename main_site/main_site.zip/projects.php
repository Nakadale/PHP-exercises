<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional// EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml11-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang = "en"
<head>
    <meta http-equiv="content-type" content="text/html;charset=iso-8859-1" />
    <title>My Website</title>
	<?php include "css_style.php" ?>
<body>

<div id="container">
	<!--Header area of webpage-->
	<div id="header" style="position: absolute; top:10px; left:10px;">
	<img src="Images/banner.jpg">
	<!--end of header of webpage-->
	<!--start of navigation area of webpage-->
	<?php include "navi.php" ?>
	<!--end of navigation area of webpage-->
	</div>
	<div id="body" style="position: absolute;top:257px;left:10px;width:980px;">
	
		<!-- right area of webpage -->
		<table style="background-color: RGB(89,146,215);" >
		<tr><td valign="top" align="center" style="width:770px;">
			<table style="background-color:RGB(83,137,207);width:750px;border:1px solid;">
				<tr><td><br /><center>
					Links to Projects made by Sherwin Lester V. Aquino with a short description
				</center><br /><center>
					Pawnshop System for A&A Pawnshop
				</center>
				<br /><center>
					Payroll System for A&A Pawnshop
				</center>
				<br /><center>
				<a href="Downloads/Setup.zip">
					MDA Reservation System for Micronesia Diving Association</a>
				</center>
				<br /><center>
					<br />Porfolio Projects made by Sherwin Lester V. Aquino</center>
				<br /><center>
				<a href="Project/index.php">Dive Reservation System</a>
					<br />A website made using PHP with MySQL.
				</center><br /><br />
				</td></tr>
				</table>
			</td><td valign="top" align="center" style="width:210px;">
			<?php include "comments.php" ?>
			<br />
		</td></tr></table>
		<!--Footer of webpage-->
		<?php include "footer.php" ?>
		<!--end of footer-->
	</div>	
</div>

</body>
</html>